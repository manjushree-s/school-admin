class Administrator {
    adminId= '';
    adminName= '';
    adminPassword= '';
}

export default Administrator;