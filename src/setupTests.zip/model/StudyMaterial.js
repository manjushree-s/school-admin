class StudyMaterial {
    studyId= '';
    name= '';
    course= '';
    teacher='';
}

export default StudyMaterial;