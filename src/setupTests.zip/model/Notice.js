class Notice {
    noticeId= '';
    name= '';
    date= '';
    notice='';
    admin='';
}

export default Notice;