class Homework {
    homeId= '';
    name= '';
    student= '';
    teacher='';
}

export default Homework;