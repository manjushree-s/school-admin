class Student {
    studentId= '';
    studentName= '';
    studentPassword= '';
    admin='';
}

export default Student;