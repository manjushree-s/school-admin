class Complaint {
    complaintId= '';
    note= '';
    student= '';
}

export default Complaint;