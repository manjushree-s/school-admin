class Teacher {
    teacherId= '';
    teacherName= '';
    teacherPassword= '';
    adin='';
}

export default Teacher;