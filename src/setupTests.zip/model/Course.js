class Course {
    courseId= '';
    name= '';
    numhrs= '';
    teacher= '';
}

export default Course;