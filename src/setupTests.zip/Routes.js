import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Header from './component/Header';
import Login from './component/Login';
import Register from './component/Register';
import PageNotFound from './component/PageNotFound';
import Home from './component/Home';

const Routes = () => {
    return (
            <div>
                <Router>
                    <div>
                        <Header />
                        <div>
                            <Switch>
                                <Route exact path="/"> <Home /> </Route>
                                <Route path="/home"> <Home /> </Route>
                                <Route path="/login"> <Login /> </Route>
                                <Route path="/register"> <Register /> </Route>
                                <Route path="/*"> <PageNotFound /> </Route>
                            </Switch>
                        </div>
                        {/* <Footer /> */}
                    </div>
                </Router>
            </div>
    );
}
export default Routes;