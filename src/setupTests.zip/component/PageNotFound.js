import React from 'react';

const PageNotFound = () => {
      return (
        
          <div className="container" >
          
              <h1 className="display-4 text-primary">PAGE NOT FOUND...</h1>
              
          </div>
          
      );
  }
  export default PageNotFound;