import React from 'react';


const Home = () => {
    return (
        
        <div className="container" >
            <h1 className="display-4 text-primary">Home Component</h1>
            <p>Welcome to this app!</p>
            
        </div>
        
    );
}

export default Home;