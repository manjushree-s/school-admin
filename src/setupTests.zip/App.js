import React from 'react';
// import store from './redux/store';
// import { Provider } from 'react-redux';
import Routes from './Routes';


const App = () => {
  return (
    <div className="background">
      <div className="bg-light">
        <Routes />
      </div>
      </div>
  );
}
export default App;

